# Agx Admin

Premium and Open Source dashboard template with responsive and high quality UI.

[![GitHub issues](https://img.shields.io/github/issues/yadav-saurabh/agx-admin.svg)](https://github.com/yadav-saurabh/agx-admin/issues) [![forks](https://img.shields.io/github/forks/yadav-saurabh/agx-admin.svg)](https://github.com/yadav-saurabh/agx-admin/fork)  [![GitHub stars](https://img.shields.io/github/stars/yadav-saurabh/agx-admin.svg)](https://github.com/yadav-saurabh/agx-admin/stargazers) [![GitHub license](https://img.shields.io/github/license/yadav-saurabh/agx-admin.svg)](https://github.com/yadav-saurabh/agx-admin/blob/master/LICENSE)


<strong><a href="https://yadav-saurabh.github.io/agx-admin/">View Demo</a> | <a href="https://github.com/yadav-saurabh/agx-admin/releases">Download</a> </strong>

<br>

| Preview |
|:---------------:|
|<a target="_blank" href="https://yadav-saurabh.github.io/agx-admin/"><img src="https://raw.githubusercontent.com/yadav-saurabh/agx-admin/master/src/assets/dashboard.png"/></a>|
