import { Component } from '@angular/core';

@Component({
  selector: 'app-basic',
  templateUrl: './basic.component.html',
  styles: ['.form-group{  margin:1rem 0;}']
})
export class BasicComponent { }
