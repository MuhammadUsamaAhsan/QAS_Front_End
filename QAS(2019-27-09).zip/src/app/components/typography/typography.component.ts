import { Component } from '@angular/core';

@Component({
  selector: 'app-typography',
  templateUrl: './typography.component.html',
  styles: ['.note{font-size: .75rem;}']
})
export class TypographyComponent { }
