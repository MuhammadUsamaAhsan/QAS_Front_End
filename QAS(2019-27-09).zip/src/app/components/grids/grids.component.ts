import { Component } from '@angular/core';

@Component({
  selector: 'app-grids',
  templateUrl: './grids.component.html',
  styles: ['.alignment{height:200px;}']
})
export class GridsComponent { }
