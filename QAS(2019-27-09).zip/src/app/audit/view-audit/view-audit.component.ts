import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-audit',
  templateUrl: './view-audit.component.html',
  styleUrls: ['./view-audit.component.scss']
})
export class ViewAuditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
