import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-standard-wash',
  templateUrl: './edit-standard-wash.component.html',
  styleUrls: ['./edit-standard-wash.component.scss']
})
export class EditStandardWashComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
