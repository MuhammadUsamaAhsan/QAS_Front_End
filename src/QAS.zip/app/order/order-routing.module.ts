import { AddOrderComponent } from './add-order/add-order.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewOrderComponent } from './view-order/view-order.component';


const routes: Routes = [
  { path: 'add-order' , component: AddOrderComponent},
  { path: 'view-order' , component: ViewOrderComponent  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OrderRoutingModule { }
