import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OrderRoutingModule } from './order-routing.module';

import { DataTablesModule } from 'angular-datatables';
import { AddOrderComponent } from './add-order/add-order.component';
import { ViewOrderComponent } from './view-order/view-order.component';

@NgModule({
  imports: [
    CommonModule,
    OrderRoutingModule,
    DataTablesModule
  ],
  declarations: [ AddOrderComponent, ViewOrderComponent]
})
export class OrderModule { }
