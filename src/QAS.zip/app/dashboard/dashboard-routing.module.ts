import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { DashboardHomeComponent } from './dashboard-home/dashboard-home.component';

const routes: Routes = [
  {
    path: '', component: DashboardComponent,
    children: [
      { path: '', component: DashboardHomeComponent },
      { path: 'components', loadChildren: '../components/components.module#ComponentsModule' },
      { path: 'forms', loadChildren: '../forms/forms.module#FormsLocalModule' },
      { path: 'tables', loadChildren: '../tables/tables.module#TablesModule' },
      { path: 'charts', loadChildren: '../charts/charts.module#ChartsModule' },
      { path: 'maps', loadChildren: '../maps/maps.module#MapsModule' },
      { path: 'editors', loadChildren: '../editors/editors.module#EditorsModule' },
      { path: 'calendar', loadChildren: '../calendar/calendar.module#CalendarModule' },
      { path: 'user', loadChildren: '../user/user.module#UserModule' },
      { path: 'fabric', loadChildren: '../fabric/fabric.module#FabricModule' },
      { path: 'supplier', loadChildren: '../supplier/supplier.module#SupplierModule' },
      { path: 'order', loadChildren: '../order/order.module#OrderModule' },
      { path: 'supplier-order', loadChildren: '../supplier-order/supplier-order.module#SupplierOrderModule' }


    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
