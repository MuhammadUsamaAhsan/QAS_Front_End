import { NgModule } from '@angular/core';
import {  RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';

//import {LoginComponent} from

const routes: Routes = [

  {
    path: '',
    redirectTo: '/login',
    pathMatch:'full',

  },
  {
     path: 'login',
     
     component: LoginComponent

  },
//   {
//     path: 'dashboard',
//     redirectTo: '/dashboard',
//     pathMatch:'full',
    
//     component: DashboardComponent

//  },

   { path: '', loadChildren: './dashboard/dashboard.module#DashboardModule' },
  

  
  { path: 'dashboard', loadChildren: './dashboard/dashboard.module#DashboardModule' },

  
  { path: '', loadChildren: './user/user.module#UserModule' },

  { path: '', loadChildren: './fabric/fabric.module#FabricModule' },

  { path: '', loadChildren: './supplier/supplier.module#SupplierModule' },
  { path: '', loadChildren: './supplier-order/supplier-order.module#SupplierOrderModule' },

  



  { path: 'forms', loadChildren: './forms/forms.module#FormsLocalModule' },
  { path: 'tables', loadChildren: './tables/tables.module#TablesModule' },
 
  { path: 'components', loadChildren: './components/components.module#ComponentsModule' }




];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule { }
