import { Component } from '@angular/core';

@Component({
  selector: 'app-add-fabric',
  templateUrl: './add-fabric.component.html',
  styleUrls: ['./add-fabric.component.scss']
})
export class AddFabricComponent {}
  


