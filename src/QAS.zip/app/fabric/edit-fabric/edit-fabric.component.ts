import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-fabric',
  templateUrl: './edit-fabric.component.html',
  styleUrls: ['./edit-fabric.component.scss']
})
export class EditFabricComponent {}

