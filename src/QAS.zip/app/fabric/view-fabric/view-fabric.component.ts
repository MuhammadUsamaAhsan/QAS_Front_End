import { Component } from '@angular/core';

@Component({
  selector: 'app-view-fabric',
  templateUrl: './view-fabric.component.html',
  styleUrls: ['./view-fabric.component.scss']
})
export class ViewFabricComponent {
  
  

    dtOptions: DataTables.Settings = {};
    data = [
      ['0001', 'qwer41'],
      ['0002', 'qwer42'],
      ['0003', 'qwer43'],
      ['0001', 'qwer41'],
      ['0001', 'qwer41'],
      ['0001', 'qwer41'],
      ['0001', 'qwer41'],
      ['0001', 'qwer41'],
      ['0001', 'qwer41'],
      ['0001', 'qwer41'],
      ['0001', 'qwer41'],
      ['0001', 'qwer41'],
      ['0001', 'qwer41']
     
    ];
  
    constructor() { }
  
    ngOnInit() {
      this.dtOptions = {
        data: this.data,
        columns: [
          { title: 'Fabric Id' },
          { title: 'Fabric Code' },

          
          {
            title: 'action', render: (data: any, type: any, full: any) => {
              return '<button id="edit" class="btn  btn-just-icon btn-round btn-light"><i class="material-icons">edit</i></button>';
            } 
          },
          {
            title: 'delete', render: (data: any, type: any, full: any) => {
              return '<button id="delete" class="btn  btn-just-icon btn-round btn-light"><i class="material-icons">delete</i></button>';
            } 
          }
        ]
      };
    }
  
  }
 
  
    