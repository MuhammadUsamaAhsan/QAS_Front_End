import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FabricRoutingModule } from './fabric-routing.module';
import { AddFabricComponent } from './add-fabric/add-fabric.component';
import { EditFabricComponent } from './edit-fabric/edit-fabric.component';
import { ViewFabricComponent } from './view-fabric/view-fabric.component';
import { DataTablesModule } from 'angular-datatables';
import { NgxMaskModule } from 'ngx-mask';

@NgModule({
  imports: [
    CommonModule,
    FabricRoutingModule,
    DataTablesModule,
    NgxMaskModule.forRoot(),
  ],
  declarations: [AddFabricComponent, EditFabricComponent, ViewFabricComponent]
})
export class FabricModule { }
