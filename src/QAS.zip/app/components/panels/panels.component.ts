import { Component } from '@angular/core';

@Component({
  selector: 'app-panels',
  templateUrl: './panels.component.html'
})
export class PanelsComponent {

}
