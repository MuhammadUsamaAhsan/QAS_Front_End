import { Component } from '@angular/core';
import { CommonService } from '../shared/services/common.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent {

  constructor(public cmnSrv: CommonService) {  }

  sidebarItems = [
    {link: '/', label: 'Dashboard', icon: 'dashboard'},
    {label: 'Components', icon: 'apps', subItem: [
      {link: '/components/buttons', label: 'buttons', icon: 'b'},
      {link: '/components/grids', label: 'grid System', icon: 'gs'},
      {link: '/components/panels', label: 'panels', icon: 'p'},
      // {link:'/components/alerts',label:'alerts',icon:'a'},
      // {link:'/components/notifications',label:'notifications',icon:'n'},
      {link: '/components/icons', label: 'icons', icon: 'i'},
      {link: '/components/typography', label: 'typography', icon: 't'},

    ]},
    



     //user forms
     {
        label: 'User', icon: 'ballot', subItem: [
      {link: '/user/add', label: 'add', icon: 'AU'},
      {link: '/user/edit', label: 'Edit', icon: 'EU'}, 
      {link: '/user/view', label: 'View', icon: 'VU'},
    ]},

    //Fabric forms
    { label: 'Fabric', icon: 'show_chart', subItem: [
      {link: '/fabric/add-fabric', label: 'Add-fabric',icon:'AF'},  
      {link: '/fabric/edit-fabric', label: 'Edit-fabric',icon:'DF'},     

      {link: '/fabric/view-fabric', label: 'View-fabric',icon:'VF'},


    ]},

    //Supplier forms
     { label: 'Supplier', icon: 'ballot', subItem: [
     {link: '/supplier/add-supplier', label: ' Add-Supplier', icon: 'AS'},
     {link: '/supplier/edit-supplier', label: 'Edit-Supplier', icon: 'ES'},
     
     {link: '/supplier/view-supplier', label: 'View-Supplier', icon: 'VS'}
    ]},


    //Order forms
    { label: 'Order', icon: 'date_range', subItem: [
      {link: '/order/add-order', label: ' Add-Order', icon: 'AO'},
     // {link: '/order/Edit', label: 'Edit Order', icon: 'EO'},
      
      {link: '/order/view-order', label: 'View-Order', icon: 'VO'}
     ]},
     
     //Supplier-order forms
     { label: 'Supplier-Order', icon: 'ballot', subItem: [
      {link: '/supplier-order/add-supplier-order', label: ' Add-Supplier', icon: 'ASO'},
     // {link: '/supplier-order/edit-supplier-order', label: 'Edit-Supplier', icon: 'ESO'},
      
      {link: '/supplier-order/view-supplier-order', label: 'View-Supplier', icon: 'VSO'}
     ]},


    {label: 'Pages', icon: 'pages', subItem: [
      {link: '/pages/notfound', label: 'Not Found', icon: 'nf'},
      {link: '/pages/auth', label: 'Auth', icon: 'A'}
    ]},
    { label: 'Tables', icon: 'grid_on', subItem: [
      {link: '/tables/basic', label: 'Basic Table', icon: 'BT'},
      {link: '/tables/smart', label: 'smart table', icon: 'ST'}
    ]},
    {label: 'Forms', icon: 'ballot', subItem: [
      {link: '/forms/basic', label: 'basic form', icon: 'bf'},
      {link: '/forms/advance', label: 'advanced form', icon: 'af'},
      {link: '/forms/custom', label: 'custom form', icon: 'cf'},
      // {link:'/forms/validations',label:'Form Validation',icon:'fv'}
    ]},

   


    {link: '/charts', label: 'Charts', icon: 'show_chart'},
    {link: '/maps', label: 'Maps', icon: 'place'},
    {link: '/editors', label: 'Editors', icon: 'edit'},
    {link: '/calendar', label: 'Calendar', icon: 'date_range'},
    {label: 'Menu', icon: 'menu', subItem: [
      {link: 'void()', label: 'Sub Menu L1', icon: 'l1'},
      { label: 'Sub Menu L1', icon: 'l1' , subItem: [
        {link: 'void()', label: 'Sub Menu L2', icon: 'l2'},
        {link: 'void()', label: 'Sub Menu L2', icon: 'l2'},
      ]},
    ]}
  ];

}
