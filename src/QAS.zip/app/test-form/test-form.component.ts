import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-form',
  templateUrl: './test-form.component.html',
  styleUrls: ['./test-form.component.scss']
})
export class TestFormComponent implements OnInit {

  private username:any;
  private password:any;

  constructor() {
   }

  ngOnInit() {
  }

  loginUser(userData):void{
    console.log("form Submitted");
    console.log(userData);
  }
}
