
import { DataTablesModule } from 'angular-datatables';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';


import { UserRoutingModule } from './user-routing.module';
import { AddComponent } from './add/add.component';
import { EditComponent } from './edit/edit.component';

import { ViewComponent } from './view/view.component';

import {NgxMaskModule} from 'ngx-mask';




@NgModule({
  imports: [
    CommonModule,
    UserRoutingModule,
    DataTablesModule,
    NgxMaskModule.forRoot(),
    

   
   
  ],
  declarations: [AddComponent, EditComponent,  ViewComponent]
})
export class UserModule { }
