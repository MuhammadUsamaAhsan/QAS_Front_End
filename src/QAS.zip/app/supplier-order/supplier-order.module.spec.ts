import { SupplierOrderModule } from './supplier-order.module';

describe('SupplierOrderModule', () => {
  let supplierOrderModule: SupplierOrderModule;

  beforeEach(() => {
    supplierOrderModule = new SupplierOrderModule();
  });

  it('should create an instance', () => {
    expect(supplierOrderModule).toBeTruthy();
  });
});
