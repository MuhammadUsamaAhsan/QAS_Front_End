import { Component } from '@angular/core';

@Component({
  selector: 'app-add-supplier-order',
  templateUrl: './add-supplier-order.component.html',
  styleUrls: ['./add-supplier-order.component.scss']
})
export class AddSupplierOrderComponent {


  
  title = 'app';
  selectedFabric = 0;
  selectedOrder = 0;


  onSelectFabric(fabric_id: number) {
    this.selectedFabric = fabric_id;
   
    //return country_id === Number(country_id)
    //return country_id;
    return this.selectedFabric;
  }

  onSelectOrder(order_no: number){

    return this.selectedOrder;
  }



  getOrder(){

    return[

      { id: 1, name: 'ASDF34'},
      { id: 2, name: 'ASDF35'},
      { id: 3, name: 'ASDF36'},
      { id: 4, name: 'ASDF37'},
      { id: 5, name: 'ASDF38'},
      { id: 6, name: 'ASDF39'}


    ];



  }

  getFabric() {
    return [
      { id: 1, name: '234U10' },
      { id: 2, name: '1234rt' },
      { id: 3, name: '1243re' },
      { id: 4, name: 'asdew12' },
      { id: 5, name: 'sad12kj' },
      { id: 6, name: '98er56' },
      { id: 7, name: '1345ty' },
      { id: 8, name: 'asdf67' },
      { id: 9, name: 'FDE345' },
      


    ];
  }




}