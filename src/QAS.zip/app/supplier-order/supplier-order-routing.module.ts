import { ViewSupplierOrderComponent } from './view-supplier-order/view-supplier-order.component';
import { AddSupplierOrderComponent } from './add-supplier-order/add-supplier-order.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [

  { path: 'add-supplier-order' , component: AddSupplierOrderComponent },
 // { path: 'edit', component: EditComponent },
 
  { path: 'view-supplier-order', component: ViewSupplierOrderComponent },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SupplierOrderRoutingModule { }
