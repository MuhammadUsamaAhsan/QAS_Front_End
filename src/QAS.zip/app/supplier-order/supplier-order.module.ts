import { DataTablesModule } from 'angular-datatables';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SupplierOrderRoutingModule } from './supplier-order-routing.module';
import { AddSupplierOrderComponent } from './add-supplier-order/add-supplier-order.component';
import { ViewSupplierOrderComponent } from './view-supplier-order/view-supplier-order.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { NgxMaskModule } from 'ngx-mask';

@NgModule({
  imports: [
    CommonModule,
    SupplierOrderRoutingModule,
    NgSelectModule,
    FormsModule,
    DataTablesModule,
    NgxMaskModule.forRoot(),
  ],
  declarations: [AddSupplierOrderComponent, ViewSupplierOrderComponent]
})
export class SupplierOrderModule { }
