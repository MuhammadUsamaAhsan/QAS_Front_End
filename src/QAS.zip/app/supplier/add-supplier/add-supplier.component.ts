import { Component } from '@angular/core';


@Component({
  selector: 'app-add-supplier',
  templateUrl: './add-supplier.component.html',
  styleUrls: ['./add-supplier.component.scss']
})
export class AddSupplierComponent {


  selectedCountry = 0;
  title = 'app';


  onSelectCountry(country_id: number) {
    this.selectedCountry = country_id;
   
    //return country_id === Number(country_id)
    //return country_id;
    return this.selectedCountry;
  }

  getCountries() {
    return [
      { id: 1, name: 'India' },
      { id: 2, name: 'USA' },
      { id: 3, name: 'Australia' },
      { id: 4, name: 'Germany' },
      { id: 5, name: 'France' },
      { id: 6, name: 'America' },
      { id: 7, name: 'canada' },
      { id: 8, name: 'UK' },
      { id: 9, name: 'Pakistan' },
      { id: 10, name: 'UAE' },
      { id: 11, name: 'China' },
      { id: 12, name: 'Japan' },
      { id: 13, name: 'Norway' },
      { id: 14, name: 'Brazil' },
      { id: 15, name: 'Argentina' },
      { id: 16, name: 'Australia' },
      { id: 17, name: 'Australia' },
      { id: 18, name: 'Australia' },
      { id: 19, name: 'Australia' },


    ];
  }

}


