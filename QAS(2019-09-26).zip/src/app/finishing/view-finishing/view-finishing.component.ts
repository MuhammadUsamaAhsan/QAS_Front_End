import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-finishing',
  templateUrl: './view-finishing.component.html',
  styleUrls: ['./view-finishing.component.scss']
})
export class ViewFinishingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
