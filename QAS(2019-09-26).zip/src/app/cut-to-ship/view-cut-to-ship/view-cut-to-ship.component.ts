import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-cut-to-ship',
  templateUrl: './view-cut-to-ship.component.html',
  styleUrls: ['./view-cut-to-ship.component.scss']
})
export class ViewCutToShipComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
